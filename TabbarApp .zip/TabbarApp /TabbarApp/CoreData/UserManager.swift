//
//  UserManager.swift
//  TabbarApp
//
//  Created by SADDAM KHAN on 21/03/23.
//

import Foundation
import CoreData

class UserManager {
    
    static let shared = UserManager()
    
    private init() {}
    
    func createUser(firstName: String, lastName: String, email: String, contact: String, password: String) -> (errorCode: Int, errorMessage: String) {
        
        
        let checkUserExistResult = checkUserExist(emailId: email, contactNumber: contact)

        if checkUserExistResult.errorCode == 200 {
            let user = User(context: CoreDataManager.shared.context)
            let userCount = userStandard.integer(forKey: UserDefaultKey.registerUserCount.rawValue) + 1
            user.userId = "\(userCount)"
            user.firstName = firstName
            user.lastName = lastName
            user.emailId = email
            user.contactNumber = contact
            user.password = password
            user.profileImage = ""
            userStandard.set(userCount, forKey: UserDefaultKey.registerUserCount.rawValue)
            CoreDataManager.shared.saveContext()
            return (errorCode: checkUserExistResult.errorCode, errorMessage: checkUserExistResult.errorMessage)
        }
        return (errorCode: checkUserExistResult.errorCode, errorMessage: checkUserExistResult.errorMessage)
    }

    //MARK: Most of time available on server side.
    private func checkUserExist(emailId: String, contactNumber: String) -> (errorCode: Int, errorMessage: String) {

        
        let fetchRequest = NSFetchRequest<User>(entityName: User.description())
//        let predicate = NSPredicate(format: "emailId==%@", emailId as CVarArg)
//        let predicate = NSPredicate(format: "contactNumber==%@", contactNumber as CVarArg)
        //TODO: Complex Predicate
        let emailPredicate = NSPredicate(format: "emailId==%@", emailId as CVarArg)
        let contactPredicate = NSPredicate(format: "contactNumber==%@", contactNumber as CVarArg)
        let andPredicate = NSCompoundPredicate(type: .or, subpredicates: [emailPredicate, contactPredicate])
        fetchRequest.predicate = andPredicate

        do {
            if let users = try CoreDataManager.shared.context.fetch(fetchRequest) as? [User] {
                if users.count == 1 {
                    
                    if users.first!.emailId == emailId {
                        return (errorCode: 201, errorMessage: "Email already register")
                        
                    }
                    else if users.first!.contactNumber == contactNumber {
                        return (errorCode: 201, errorMessage: "Contact already register")
                    }
                }
                return (errorCode: 200, errorMessage: "User successfully create")
            }
        }
        catch {
            print("Error occured during fetch students: \(error)")
        }
        return (errorCode: 200, errorMessage: "User successfully create")
    }
    
    
    func checkUserAbleToLogin(emailId: String, password: String) -> (errorCode: Int, errorMessage: String, userDetails: User?) {

        let fetchRequest = NSFetchRequest<User>(entityName: User.description())
        let predicate = NSPredicate(format: "emailId==%@", emailId as CVarArg)
        fetchRequest.predicate = predicate

        do {
            if let users = try CoreDataManager.shared.context.fetch(fetchRequest) as? [User] {
                if users.count == 1 {
                    if users.first!.password == password {
                        
                        return (errorCode: 200, errorMessage: "Success", userDetails: users.first)
                    }
                    else {
                        return (errorCode: 201, errorMessage: "Invalid Password!", userDetails: nil)
                    }
                }
                return (errorCode: 202, errorMessage: "User not exist", userDetails: nil)
            }
        }
        catch {
            print("Error occured during fetch students: \(error)")
        }
        return (errorCode: 202, errorMessage: "User not exist", userDetails: nil)
    }
    
    
    //MARK: Update User Details.
    func updateUser(userId: String, firstName: String = "", lastName: String = "", email: String = "", contact: String = "", profileImageName: String = "") -> (errorCode: Int, errorMessage: String) {

        let fetchRequest = NSFetchRequest<User>(entityName: User.description())
        let predicate = NSPredicate(format: "userId==%@", userId as CVarArg)
        fetchRequest.predicate = predicate

        do {
            if let users = try CoreDataManager.shared.context.fetch(fetchRequest) as? [User] {
                if users.count == 1 {
                    let user = users.first!
                    
                    if profileImageName == "" {
                        user.firstName = firstName
                        user.lastName = lastName
                        user.emailId = email
                        user.contactNumber = contact
                        user.profileImage = ""
                    }
                    else {
                        user.profileImage = profileImageName
                    }
                    
                    CoreDataManager.shared.saveContext()
                    return (errorCode: 200, errorMessage: "Profile data successfully updated")
                }
                return (errorCode: 201, errorMessage: "User not exist")
            }
        }
        catch {
            print("Error occured during fetch students: \(error)")
        }
        return (errorCode: 201, errorMessage: "User not exist")
    }
    
    //MARK: Delete User Account
    func deleteUser(userId: String) -> (errorCode: Int, errorMessage: String) {

        let fetchRequest = NSFetchRequest<User>(entityName: User.description())
        let predicate = NSPredicate(format: "userId==%@", userId as CVarArg)
        fetchRequest.predicate = predicate

        do {
            if let users = try CoreDataManager.shared.context.fetch(fetchRequest) as? [User] {
                if users.count == 1 {
                    let user = users.first!
                    CoreDataManager.shared.context.delete(user)
                    CoreDataManager.shared.saveContext()
                    return (errorCode: 200, errorMessage: "User successfully deleted!")
                }
                return (errorCode: 201, errorMessage: "User not exist")
            }
        }
        catch {
            print("Error occured during fetch students: \(error)")
        }
        return (errorCode: 201, errorMessage: "User not exist")
    }

    //MARK: Fetch user list
    func getUserList() -> [User] {
        
        var userList = [User]()
        
        do {
            let users = try CoreDataManager.shared.context.fetch(User.fetchRequest())
            
            userList = users
        }
        catch let error {
            print(error)
        }
        return userList
    }
    
    func getUserList2ndMethod() -> [User] {
        
        
        let fetchRequest = NSFetchRequest<User>(entityName: User.description())
        
        
        do {
            if let users = try CoreDataManager.shared.context.fetch(fetchRequest) as? [User] {
                return users
            }
        }
        catch {
            print("Error occured during fetch students: \(error)")
        }
        return []
    }
}
