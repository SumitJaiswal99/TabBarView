//
//  Food.swift
//  TabbarApp
//
//  Created by iPHTech40 on 01/03/23.
//

import Foundation

struct Food {
    
    let foodName: String

    static func defaultFoodList() -> [Food] {

        var foodList = [Food]()
        foodList.append(Food(foodName: "Apple"))
        foodList.append(Food(foodName: "Grape"))
        foodList.append(Food(foodName: "Guava"))
        foodList.append(Food(foodName: "Mango"))
        foodList.append(Food(foodName: "Papaya"))
        return foodList
    }
}
