//
//  ImageShowCollectionViewController.swift
//  TabbarApp
//
//  Created by iPHTech40 on 02/03/23.
//

import UIKit

protocol ImageShowCollectionViewControllerDelegate: AnyObject {
    
    func addOrUpdateFood(food: Food, index: Int)
    func deleteFood(index: Int)
    
}

class ImageShowCollectionViewController: UIViewController {
    
    //MARK: IBOutlet
    @IBOutlet var imageShow: UIImageView!
    @IBOutlet weak var foodTextField: UITextField!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var deleteBarButton: UIBarButtonItem!
    
    
    var foodData: Food?
    weak var delegate: ImageShowCollectionViewControllerDelegate?
    var presentIndex: Int?
    
    
    
    //MARK: object
    var imageReceived = UIImage()
    
    
    //MARK: Hide Tab Bar Icon
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
    
    //MARK: Life Cycle Method
    override func viewDidLoad() {
        super.viewDidLoad()
        imageShow.image = imageReceived
        setupUI()
    }
    
    
    private func setupUI() {
        
        updateButton.layer.cornerRadius = 12.0
        updateButton.layer.borderWidth = 0.0
        updateButton.layer.shadowOffset = CGSize(width: 0.0,height: 5)
        updateButton.layer.shadowRadius = 5
        updateButton.layer.shadowOpacity = 0.3
        updateButton.layer.masksToBounds = false
        
        if foodData == nil {
            updateButton.setTitle("Add", for: .normal)
            deleteBarButton.isHidden = true
        }
        else {
            updateButton.setTitle("Update", for: .normal)
            deleteBarButton.isHidden = false
        }
    }
    
    
    @IBAction func updateButtonAction(_ sender: Any) {
        
        delegate?.addOrUpdateFood(food: Food(foodName: foodTextField.text ?? ""), index: presentIndex ?? -1)
        
        navigationController?.popViewController(animated: true)
        
    }
    
    
    @IBAction func deleteButtonTapped(_ sender: Any) {
        
        Alert.shared.showAlert(vc: self, title: "Refresh", message: "Are you sure you want to delete the item?", yesActionTitle: "Yes", noActionTitle: "No") { [weak self] value in
            guard let self = self else { return }
            if value == "Yes" {
                //print("Handle Ok logic here")
                self.delegate?.deleteFood(index: self.presentIndex ?? -1)
                self.navigationController?.popViewController(animated: true)
            }
            else {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
}
