//
//  FriendListViewController.swift
//  TabbarApp
//
//  Created by Saddam Khan on 27/02/23.
//

import UIKit

class FoodListViewController: UIViewController {
    
    //MARK: IBOutlet
    @IBOutlet weak var myCollectionView: UICollectionView!
    
    //MARK: Variable
    var foodListArray = [Food]()
    
    
    //MARK: Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        foodListArray = Food.defaultFoodList()
    }
    
    
    //MARK: nextPageButtonAction
    @IBAction func nextPageButtonAction(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ImageShowCollectionViewController") as! ImageShowCollectionViewController
        //  vc.imageReceived.image = UIImage(named: foodListArray[presentIndex.row].foodName)
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

//MARK: UICollectionViewDelegate & UICollectionViewDataSource
extension FoodListViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        foodListArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = myCollectionView.dequeueReusableCell(withReuseIdentifier: "MyCollectionViewCell", for: indexPath) as! MyCollectionViewCell
        cell.myImageView.image = UIImage(named: foodListArray[indexPath.row].foodName)
        //   cell.foodNameLabel.text = UIImage(named: foodListArray[indexPath.row].foodName)
        cell.foodNameLabel.text = foodListArray[indexPath.row].foodName
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if let vc = storyboard?.instantiateViewController(identifier: "ImageShowCollectionViewController") as? ImageShowCollectionViewController {
            vc.imageReceived =  UIImage(named: foodListArray[indexPath.row].foodName)!
            vc.foodData = foodListArray[indexPath.row]
            vc.presentIndex = indexPath.row
            vc.delegate = self
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension FoodListViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {

        let width = (collectionView.frame.size.width-41.0)/3.0
        return CGSize(width: width, height: width)
    }
    
}


extension FoodListViewController: ImageShowCollectionViewControllerDelegate {

    func addOrUpdateFood(food: Food, index: Int) {
        if index == -1 {
            foodListArray.append(food)
        }
        else {
            foodListArray[index] = food
        }
        myCollectionView.reloadData()
    }
    
    func deleteFood(index: Int) {
        foodListArray.remove(at: index)
        myCollectionView.reloadData()
    }
}
