//
//  TabBarViewController.swift
//  TabbarApp
//
//  Created by Saddam Khan on 28/02/23.
//

import UIKit

class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    
    //MARK: Setup UI
    private func setupUI() {
        
        self.tabBar.tintColor = .red
        self.tabBar.unselectedItemTintColor = .white
    }
}
