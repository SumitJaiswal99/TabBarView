//
//  APIUrls.swift
//  TabbarApp
//
//  Created by SADDAM KHAN on 21/04/23.
//

import Foundation
import Alamofire

enum Environment: String {

    case development = "development"
    case production = "production"
}

struct APIUrls {

    static let shared = APIUrls()
    
    struct Friend {
        static let getFriendList = "getFriendList.php"
        static let createFriend = "createFriend.php"
        static let updateFriend = "updateFriend.php"
        static let deleteFriend = "deleteFriend.php"
    }

    func getBaseUrlString() -> String {
        
        if currentApiEnvironment == .development {
            return "http://codeinventiv.com/API/"
        }
        else {
            return "https://codeinventiv.com/API/"
        }
    }

    func getHeader() -> HTTPHeaders {
        if currentApiEnvironment == .development {
            return ["Authorization" : "bd8b6a9b5130ad59c52fd3439c03fe84"]
        }
        else {
            return ["Authorization" : "bd8b6a9b5130ad59c52fd3439c03fe84"]
        }
    }
    
}
