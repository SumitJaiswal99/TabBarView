//
//  ProfileInfoTableViewCell.swift
//  TabbarApp
//
//  Created by iPHTech40 on 06/03/23.
//

import UIKit

class ProfileInfoTableViewCell: UITableViewCell {
    
   
    //MARK: IBOutelts
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var contactNumberLabel: UILabel!
    @IBOutlet weak var rollNumberLabel: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
