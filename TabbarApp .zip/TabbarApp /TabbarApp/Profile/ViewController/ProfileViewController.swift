//
//  FriendListViewController.swift
//  TabbarApp
//
//  Created by Saddam Khan on 27/02/23.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    
    //MARK: Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setData()
    }

    private func setData() {
        nameLabel.text = "\(userStandard.string(forKey: UserDefaultKey.firstName.rawValue) ?? "") \(userStandard.string(forKey: UserDefaultKey.lastName.rawValue) ?? "")"
        emailLabel.text = userStandard.string(forKey: UserDefaultKey.emailId.rawValue)
        contactLabel.text = userStandard.string(forKey: UserDefaultKey.contactNumber.rawValue)

        let folderName = "Users"
        let userId = userStandard.string(forKey: UserDefaultKey.userId.rawValue) ?? ""
        let fileName = "\(userId).jpg"

        let fileManager = FileManager.default
        let documentsFolder = try! fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let folderURL = documentsFolder.appendingPathComponent(folderName)
        let fileURL = folderURL.appendingPathComponent(fileName)
        if FileManager.default.fileExists(atPath: fileURL.path) {
            if let data = try? Data(contentsOf: fileURL), let loaded = UIImage(data: data) {
                profileImage.image = loaded
            }
        }
        
    }

    @IBAction func nextPageAction(_ sender: UIBarButtonItem) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EditProfileViewController") as! EditProfileViewController
        vc.profileImageData = profileImage.image
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
}
