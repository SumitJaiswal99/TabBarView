//
//  FriendTableViewCell.swift
//  TabbarApp
//
//  Created by iPHTech40 on 28/02/23.
//

import UIKit

class FriendTableViewCell: UITableViewCell {

    //MARK: IBOutelts
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var contactNoLabel: UILabel!
    @IBOutlet weak var profileImage: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
