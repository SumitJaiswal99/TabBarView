//
//  FriendListViewController.swift
//  TabbarApp
//
//  Created by Saddam Khan on 27/02/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import SVProgressHUD
import SDWebImage

class FriendListViewController: UIViewController {
    
    //MARK: IBOutlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var infoLabel: UILabel!
    
    //MARK: Constants
    var friendListArray = [Friend]()
    
    
    //MARK: Life Cycle Method
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        friendListArray = Friend.defaultFriendList()
        //        setupBinding()
        getFriendListData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
//        tableView.reloadData()
//        getFriendListData()

    }
    
    private func setupBinding() {
        
        //        tableView.register(FriendNewTableViewCell.self, forCellReuseIdentifier: "FriendNewTableViewCell")
        tableView.register(UINib(nibName: "FriendNewTableViewCell", bundle: nil), forCellReuseIdentifier: "FriendNewTableViewCell")
    }
    
    //MARK: Next Page Action
    @IBAction func nextPageAction(_ sender: UIBarButtonItem) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "InformationViewController") as! InformationViewController
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    private func getFriendListData() {
        
        let serviceUrl = "\(baseUrl)\(APIUrls.Friend.getFriendList)"

        SVProgressHUD.show()
        AF.request(serviceUrl, method: .get, encoding: JSONEncoding.default, headers: baseUrlHeader)
            .responseJSON { [weak self] response in
                SVProgressHUD.dismiss()
                switch response.result {
                case .success(let json):
                    
                    //With SwiftyJSON
                    //                    let jsonResult = JSON(json)
                    //                    print(jsonResult["title"])
                    
                    //By code
//                    let jsonDict = json as! Dictionary<String, Any>
                    let jsonDict = json as! NSDictionary
                    
                    let statusCode = (jsonDict["status_code"] as? Int) ?? 199
                    let msg = (jsonDict["msg"] as? String) ?? "Something went wrong"
                    
                    if statusCode == 200 {
//                        let friendList = jsonDict["FriendList"] as! Array<Any>
                        let friendList = jsonDict["FriendList"] as! NSArray
                        self?.friendListArray = Friend.parseServerDataFriendList(friendList: friendList)
                        DispatchQueue.main.async {
                            self?.infoLabel.isHidden = !(self?.friendListArray.count == 0)
                            self?.tableView.reloadData()
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            self?.infoLabel.isHidden = false
//                            SVProgressHUD.showError(withStatus: msg)
                        }
                    }
                    
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self?.infoLabel.isHidden = false
                        SVProgressHUD.showError(withStatus: "\(error)")
                    }
                }
            }
    }
    
}

extension FriendListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friendListArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendTableViewCell", for: indexPath) as! FriendTableViewCell
        //        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendNewTableViewCell", for: indexPath) as! FriendNewTableViewCell

        let isNameOn = userStandard.bool(forKey: UserDefaultKey.lastNameKey.rawValue)
        if isNameOn {
            cell.nameLabel.text = "\(friendListArray[indexPath.row].firstName)"
        }
        else {
            cell.nameLabel.text = "\(friendListArray[indexPath.row].firstName) \(friendListArray[indexPath.row].lastName)"
        }

        let isContactOn = userStandard.bool(forKey: UserDefaultKey.contactKey.rawValue)
        cell.contactNoLabel.text = isContactOn ? "" : friendListArray[indexPath.row].contact

//        let url = URL(string: friendListArray[indexPath.row].profileImg)
//        let data = try? Data(contentsOf: url!)
//        if let imageData = data {
//            let image = UIImage(data: imageData)
//            cell.profileImage.image = image
//        }
        cell.profileImage.sd_setImage(with: URL(string: friendListArray[indexPath.row].profileImg), placeholderImage: UIImage(named: "profile"))

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = storyboard?.instantiateViewController(identifier: "InformationViewController") as? InformationViewController {
            vc.friendData = friendListArray[indexPath.row]
            vc.currentIndex = indexPath.row
            vc.delegate = self
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    //MARK: DeleteOperation
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            presentDeletionFailsafe(indexPath: indexPath)
        }
    }
    
    func presentDeletionFailsafe(indexPath: IndexPath) {

        Alert.shared.showAlert(vc: self, title: "Alert", message: "Are you sure you want to delete this friends contact", yesActionTitle: "Yes") { [weak self] value in
            guard let self = self else { return }
            if value == "Yes" {
                // replace data variable with your own data array
                self.friendListArray.remove(at: indexPath.row)
                self.tableView.deleteRows(at: [IndexPath(row: indexPath.row, section: 0)], with: .left)
            }
        }


    }
    
}

extension FriendListViewController: InformationViewControllerDelegate  {
    
    func addOrUpdateFriend(friend: Friend, index: Int) {
        
        if index == -1 {
//            friendListArray.append(friend)
            getFriendListData()
        }
        else {
            friendListArray[index] = friend
        }
        tableView.reloadData()
    }
    
    func deleteFriend(index: Int) {
        friendListArray.remove(at: index)
        tableView.reloadData()
    }
    
}
