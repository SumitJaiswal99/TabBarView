//
//  InformationViewController.swift
//  TabbarApp
//
//  Created by iPHTech40 on 28/02/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import SVProgressHUD

enum FriendDataKeys: String {
    
    case friendId = "friendId"
    case firstName = "firstName"
    case lastName = "lastName"
    case contact = "contact"
}

protocol InformationViewControllerDelegate: AnyObject {
    
    func addOrUpdateFriend(friend: Friend, index: Int)
    func deleteFriend(index: Int)
}

class InformationViewController: UIViewController {
    
    //MARK: IBOutlets
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var contactTextField: UITextField!
    @IBOutlet weak var deleteBarButton: UIBarButtonItem!
    @IBOutlet weak var submitButton: UIButton!

    //MARK: Constants
    var friendData: Friend?
    weak var delegate: InformationViewControllerDelegate?
    var currentIndex: Int?
    
    //MARK: Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setData()
    }
    
    private func setupUI() {
        
        submitButton.layer.cornerRadius = 12.0
        submitButton.layer.borderWidth = 0.0
        submitButton.layer.shadowOffset = CGSize(width: 0.0,height: 5)
        submitButton.layer.shadowRadius = 5
        submitButton.layer.shadowOpacity = 0.3
        submitButton.layer.masksToBounds = false
        
        if friendData == nil {
            submitButton.setTitle("Add", for: .normal)
            deleteBarButton.isHidden = true
        }
        else {
            submitButton.setTitle("Update", for: .normal)
            deleteBarButton.isHidden = false
        }
    }
    
    private func setData() {
        
        firstNameTextField.text = "\(friendData?.firstName ?? "")"
        lastNameTextField.text = "\(friendData?.lastName ?? "")"
        contactTextField.text = "\(friendData?.contact ?? "")"
    }
    
    //MARK: submitAction
    @IBAction func submitAction(_ sender: UIButton) {
        
        if firstNameTextField.text == "" || lastNameTextField.text == "" || contactTextField.text == "" {
            navigationController?.popViewController(animated: true)
            return
        }
        
        
        if currentIndex != nil {
            updateFriendData()
        }
        else {
            addFriendData()
        }
    }
    
    private func addFriendData() {
        
        let serviceUrl = "\(baseUrl)\(APIUrls.Friend.createFriend)"
        
        SVProgressHUD.show()
        let parameter = [
            FriendDataKeys.firstName.rawValue: firstNameTextField.text ?? "",
            FriendDataKeys.lastName.rawValue: lastNameTextField.text ?? "",
            FriendDataKeys.contact.rawValue: contactTextField.text ?? ""
        ] as [String : Any]

        AF.request(serviceUrl, method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: baseUrlHeader)
            .responseJSON { [weak self] response in
                SVProgressHUD.dismiss()
                switch response.result {
                case .success(let json):
                    
                    let jsonDict = json as! Dictionary<String, Any>
                    let statusCode = (jsonDict["status_code"] as? Int) ?? 199
                    let msg = (jsonDict["msg"] as? String) ?? "Something went wrong"
                    
                    if statusCode == 200 {
                        DispatchQueue.main.async {
                            self?.delegate?.addOrUpdateFriend(friend: Friend(friendId: self?.friendData?.friendId ?? 0, firstName: self?.firstNameTextField.text ?? "", lastName: self?.lastNameTextField.text ?? "", contact: self?.contactTextField.text ?? ""), index: self?.currentIndex ?? -1)
                            self?.navigationController?.popViewController(animated: true)
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            SVProgressHUD.showError(withStatus: msg)
                        }
                    }
                    
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        SVProgressHUD.showError(withStatus: "\(error)")
                    }
                }
            }
    }
    
    
    private func updateFriendData() {
        
        let serviceUrl = "\(baseUrl)\(APIUrls.Friend.updateFriend)"
        
        SVProgressHUD.show()
        let parameter = [
            FriendDataKeys.friendId.rawValue: friendData?.friendId,
            FriendDataKeys.firstName.rawValue: firstNameTextField.text ?? "",
            FriendDataKeys.lastName.rawValue: lastNameTextField.text ?? "",
            FriendDataKeys.contact.rawValue: contactTextField.text ?? ""
        ] as [String : Any]

        AF.request(serviceUrl, method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: baseUrlHeader)
            .responseJSON { [weak self] response in
                SVProgressHUD.dismiss()
                switch response.result {
                case .success(let json):
                    
                    let jsonDict = json as! Dictionary<String, Any>
                    let statusCode = (jsonDict["status_code"] as? Int) ?? 199
                    let msg = (jsonDict["msg"] as? String) ?? "Something went wrong"
                    
                    if statusCode == 200 {
                        DispatchQueue.main.async {
                            self?.delegate?.addOrUpdateFriend(friend: Friend(friendId: self?.friendData?.friendId ?? 0, firstName: self?.firstNameTextField.text ?? "", lastName: self?.lastNameTextField.text ?? "", contact: self?.contactTextField.text ?? ""), index: self?.currentIndex ?? -1)
                            self?.navigationController?.popViewController(animated: true)
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            SVProgressHUD.showError(withStatus: msg)
                        }
                    }
                    
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        SVProgressHUD.showError(withStatus: "\(error)")
                    }
                }
            }
    }
    
    @IBAction func deleteAction(_ sender: UIBarButtonItem) {
        
        Alert.shared.showAlert(vc: self, title: "Refresh", message: "Are you sure you want to delete the item?", yesActionTitle: "Yes") { [weak self] value in
            guard let self = self else { return }
            if value == "Yes" {
                //print("Handle Ok logic here")
                self.deleteFriendData()
            }
        }
    }
    
    private func deleteFriendData() {
        
        let serviceUrl = "\(baseUrl)\(APIUrls.Friend.deleteFriend)"

        SVProgressHUD.show()
        let parameter = [ FriendDataKeys.friendId.rawValue: friendData?.friendId ]

        AF.request(serviceUrl, method: .post, parameters: parameter, encoding: JSONEncoding.default, headers: baseUrlHeader)
            .responseJSON { [weak self] response in
                SVProgressHUD.dismiss()
                switch response.result {
                case .success(let json):
                    
                    let jsonDict = json as! Dictionary<String, Any>
                    let statusCode = (jsonDict["status_code"] as? Int) ?? 199
                    let msg = (jsonDict["msg"] as? String) ?? "Something went wrong"
                    
                    if statusCode == 200 {
                        DispatchQueue.main.async {
                            self?.delegate?.deleteFriend(index: self?.currentIndex ?? -1)
                            self?.navigationController?.popViewController(animated: true)
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            SVProgressHUD.showError(withStatus: msg)
                        }
                    }
                    
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        SVProgressHUD.showError(withStatus: "\(error)")
                    }
                }
            }
    }
    
}
