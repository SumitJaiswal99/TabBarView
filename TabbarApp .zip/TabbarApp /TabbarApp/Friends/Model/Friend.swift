//
//  Friends.swift
//  TabbarApp
//
//  Created by Saddam Khan on 01/03/23.
//

import Foundation

struct Friend {
    
    let friendId: Int
    let firstName: String
    let lastName: String
    let contact: String
    let profileImg: String = "https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg"
    
    static func defaultFriendList() -> [Friend] {
        
        var friendList = [Friend]()
        friendList.append(Friend(friendId: 1, firstName: "Ajay", lastName: "Kumar", contact: "7894561234"))
        friendList.append(Friend(friendId: 2, firstName: "Faisal", lastName: "Khan", contact: "9994561234"))
        friendList.append(Friend(friendId: 3, firstName: "Madhukar", lastName: "Panday", contact: "7894001234"))
        friendList.append(Friend(friendId: 4, firstName: "Faizan", lastName: "Khan", contact: "7894009934"))
        friendList.append(Friend(friendId: 5, firstName: "Sumit", lastName: "Jaiswal", contact: "7888001234"))
        return friendList
    }

    static func parseServerDataFriendList(friendList: NSArray) -> [Friend] {
        
        var friendlist = [Friend]()
        
        for friendData in friendList {
            let data = friendData as! Dictionary<String, Any>
            let friendId = (data["friendId"] as? Int) ?? -1
            let firstName = (data["firstName"] as? String) ?? "-"
            let lastName = (data["lastName"] as? String) ?? "-"
            let contact = (data["contact"] as? String) ?? "XXX XXX XXXX"
            friendlist.append(Friend(friendId: friendId, firstName: firstName, lastName: lastName, contact: contact))
        }
        return friendlist
    }
    
}
